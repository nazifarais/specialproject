<?php 
include('vendor/inc/config.php');
 ?>

<!DOCTYPE html>
<html>
   <head>
      <title>Gmail Sender</title>
      <link rel="stylesheet" href="vendor/Appscript/style.css">
   </head>
   <body>
      <div class="wrapper">
         <form method="post" action="gmail.php">
            <h2>Gmail Sender App</h2><br>
            Email To :<br>
            <input type="text" name="email"><br>
            Subject :<br>
            <input type="text" name="subject"><br>
            Body :<br>
            <textarea name="body"></textarea><br>
            <input type="submit" value="SEND" name="submit">
            <a class="nav-link" href="admin-dashboard.php">Back To Dashboard</a>            
         </form>
         <?php
         if(isset($_POST['submit'])){
            $url = "https://script.google.com/macros/s/AKfycbwvMlmb2uU1_1voERYF4A1n7twIZBzlFnqcof_U9C3QirxtQbebO444RcZ2x0l8FQ9o/exec";
            $ch = curl_init($url);
            curl_setopt_array($ch, [
               CURLOPT_RETURNTRANSFER => true,
               CURLOPT_FOLLOWLOCATION => true,
               CURLOPT_POSTFIELDS => http_build_query([
                  "recipient" => $_POST['email'],
                  "subject"   => $_POST['subject'],
                  "body"      => $_POST['body']
               ])
            ]);
            $result = curl_exec($ch);
            echo $result;

            // penambahan untuk notif
            $email = $_POST['email'];
            $subject = $_POST['subject'];
            $body = $_POST['body'];
            $insert_data = "INSERT INTO tms_email_message (email, subject, body) VALUES ('$email','$subject','$body')"; 
            $data_file = mysqli_query($mysqli, $insert_data);
            // until here
         }
         ?>
      </div>
      
   </body>
</html>