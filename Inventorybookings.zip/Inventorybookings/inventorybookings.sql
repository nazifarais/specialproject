-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 28, 2022 at 01:36 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventorybookings`
--

-- --------------------------------------------------------

--
-- Table structure for table `tms_admin`
--

CREATE TABLE `tms_admin` (
  `a_id` int(20) NOT NULL,
  `a_name` varchar(200) NOT NULL,
  `a_email` varchar(200) NOT NULL,
  `a_pwd` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tms_admin`
--

INSERT INTO `tms_admin` (`a_id`, `a_name`, `a_email`, `a_pwd`) VALUES
(1, 'System Admin', 'admin@mail.com', 'Nu@843532');

-- --------------------------------------------------------

--
-- Table structure for table `tms_email_message`
--

CREATE TABLE `tms_email_message` (
  `id_email_message` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `body` text,
  `status` enum('0','1') DEFAULT '0',
  `date_message` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tms_email_message`
--

INSERT INTO `tms_email_message` (`id_email_message`, `email`, `subject`, `body`, `status`, `date_message`) VALUES
(1, 'veranialoissintia@gmail.com', '12345', 'fsdfsdf', '1', '2022-11-30 14:13:12'),
(3, 'Khalis@mail.com', 'baba', 'meyou', '1', '2022-11-30 14:14:14'),
(5, 'veranialoissintia@gmail.com', 'gdfg', 'fggfgdg', '1', '2022-11-30 14:14:07'),
(6, 'nazifarais02@gmail.com', 'Fine', 'you are exceed date. ', '1', '2022-12-01 06:35:42'),
(7, 'charlieputh@mail.com', 'Expired', 'You Need to Pay for you fine.', '1', '2022-12-04 00:35:25'),
(8, 'charlieputh@mail.com', 'Fine', 'You need to pay RM50 for not return inventory.', '1', '2022-12-05 02:12:51'),
(9, 'nuraiqha@gmail.com', 'Fine', 'You need to pay RM50 for not return inventory.', '1', '2022-12-05 02:21:59'),
(10, 'nazifarais02@gmail.com', 'Expired', 'Your Booking Id has Expired.', '1', '2022-12-23 03:47:18');

-- --------------------------------------------------------

--
-- Table structure for table `tms_feedback`
--

CREATE TABLE `tms_feedback` (
  `f_id` int(20) NOT NULL,
  `f_uname` varchar(200) NOT NULL,
  `f_content` longtext NOT NULL,
  `f_status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tms_feedback`
--

INSERT INTO `tms_feedback` (`f_id`, `f_uname`, `f_content`, `f_status`) VALUES
(1, 'Elliot Gape', 'Sample Feedback Text for testing! Sample Feedback Text for testing! Sample Feedback Text for testing!', 'Published'),
(2, 'Mark L. Anderson', 'This is a demo feedback text. This is a demo feedback text. This is a demo feedback text.', 'Published'),
(3, 'Liam Moore', 'test number 3', '');

-- --------------------------------------------------------

--
-- Table structure for table `tms_inventory`
--

CREATE TABLE `tms_inventory` (
  `inv_id` int(20) NOT NULL,
  `inv_name` varchar(200) NOT NULL,
  `inv_desc` varchar(200) NOT NULL,
  `inv_no` varchar(200) NOT NULL,
  `inv_dpic` varchar(200) NOT NULL,
  `inv_status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tms_inventory`
--

INSERT INTO `tms_inventory` (`inv_id`, `inv_name`, `inv_desc`, `inv_no`, `inv_dpic`, `inv_status`) VALUES
(1, 'Dell S2216H 22', '1920 x 1080 @ 60 Hz, UltraWide View Angle', '5', 'monitor.webp', 'Available'),
(2, 'POWER SUPPLY DELL OPTIPLEX 380 MINI TOWER', 'Genuine Dell 280W Replacement  Desktop Power Supply  Input: 100-120V or 200-240V input |Output: 280W Max | Connectors: .\\t1 x 24-pin ATX Connector, 2 x SATA Power Connectors, 1 x 4-Pin Molex,', '5', 'power.jpg', 'Available'),
(3, 'HDMI Flat Cable 4K High Speed Plated Connectors 3m (Rose Gold)', '1. The cable is 30AWG multi-shielded A male to A male HDMI cable, flexible flat cable is not easy to be broken.', '5', 'flatcrose.jpg', 'Available'),
(4, 'RJ 45 Connector Cat6', 'RJ45-Connector for category cable assemblies.', '100', 'connectorc6.jpg', 'Available'),
(5, 'POWER SUPPLY DELL OPTIPLEX 8500', 'ell 460W Power Supply Unit PSU For Dell XPS 7100, 8300 Systems 460W Max Output/ 100-240V Input/ Compatible Systems: Dell XPS 7100,8300 Connectors: P1:24 pin motherboard connector, P2:4 pin connector ,', '7', 'supply.jpg', 'Available'),
(6, 'SanDisk Ultra USB 3.0 Flash Drive 16GB', 'Transfer a full-length movie in less than 30 seconds (32GB-128GB), Sleek and durable metal casing', '10', '16gb.jpg', 'Available'),
(7, 'POWER SUPPLY DELL OPTIPLEX 360', 'Genuine Dell 255 Watt Power Supply For Optilex 360, 380, 760, 780 , 960 Mini Tower', '5', 'dell.jpg', 'Available'),
(8, 'SanDisk Ultra USB 3.0 Flash Drive 8GB', '-It move files quickly with USB 3.0 speed', '10', 'sandisk.jpg', 'Available'),
(9, '10FT 3 PIN XLR CONNECTOR MALE TO 1/8\"3.5MM MALE STEREOJACK MICROPHONE AUDIO CORD CABLE', '1/8\"3.5MM MALE STEREOJACK MICROPHONE AUDIO CORD CABLE', '2', 'connector.jpg', 'Available'),
(10, 'LOGITECH KEYBOARD USB 3.0 K120', 'K120 Corded is reliable and durable, equipped with a number pad with an easy-to-use design that works right out of the box. Just plug in this corded keyboard via USB and go.', '10', 'keyboard.jpg', 'Available'),
(11, 'Seagate HDD 1TB Backup Plus Slim Portable External Hard Disk Drive(Gold)', '3 Years local Malaysia manufacturer warranty more portable thin & light at only 159g', '2', 'seagate.jpg', 'Available'),
(12, 'Kingston 4GB HyperX Fury Blue DDR3 RAM (1600MHz - CL10 - HX316C10F/4)', '-4GB Desktop RAM, DDR3 1600MHz', '5', 'kingston.jpg', 'Available'),
(13, 'Logitech R800 Wireless Presenter Green Laser Pointer 2.4Ghz PPT USB', 'Brilliant Red Laser, Intuitive slideshow controls', '1', 'logitechppt.jpg', 'Available'),
(14, 'ReanneQ Cabin Size 20\" 4 Wheel Light Weight Carry on Luggage Bag', 'Lightweight, Waterproof', '1', 'luggage.jpg', 'Booked'),
(15, 'NKTM Multi-Functional Network Crimping Pliers Labor-saving Cable Clamp Pliers ', 'for 4P,6P,8P Ratcheting Modular Crimper Stripper Cutter', '1', 'nktm.jpg', 'Booked');

-- --------------------------------------------------------

--
-- Table structure for table `tms_pwd_resets`
--

CREATE TABLE `tms_pwd_resets` (
  `r_id` int(20) NOT NULL,
  `r_email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tms_pwd_resets`
--

INSERT INTO `tms_pwd_resets` (`r_id`, `r_email`) VALUES
(2, 'admin@mail.com'),
(3, 'nazifarais02@gmail.com'),
(4, 'admin@mail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tms_user`
--

CREATE TABLE `tms_user` (
  `u_id` int(20) NOT NULL,
  `u_fname` varchar(200) NOT NULL,
  `u_lname` varchar(200) NOT NULL,
  `u_phone` varchar(200) NOT NULL,
  `u_addr` varchar(200) NOT NULL,
  `u_category` varchar(200) NOT NULL,
  `u_email` varchar(200) NOT NULL,
  `u_pwd` varchar(20) NOT NULL,
  `u_inv_bookqty` varchar(200) NOT NULL,
  `u_inv_booktime` varchar(200) NOT NULL,
  `u_inv_bookdate` varchar(200) NOT NULL,
  `u_inv_returndate` varchar(200) NOT NULL,
  `u_inv_book_status` varchar(200) NOT NULL,
  `inv_id` int(20) NOT NULL,
  `inv_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tms_user`
--

INSERT INTO `tms_user` (`u_id`, `u_fname`, `u_lname`, `u_phone`, `u_addr`, `u_category`, `u_email`, `u_pwd`, `u_inv_bookqty`, `u_inv_booktime`, `u_inv_bookdate`, `u_inv_returndate`, `u_inv_book_status`, `inv_id`, `inv_name`) VALUES
(1, 'Vincent', 'Pelletier', '4580001456', '58 Farland Avenue', 'User', 'vincent@gmail.com', 'password', '', '', '', '', '', 0, ''),
(2, 'Paul', 'Mills', '7412563258', '12 Red Maple Drive', 'User', 'paul@gmail.com', 'password', '', '', '', '', '', 0, ''),
(3, 'Jesse', 'Robinson', '1458887855', '73 Fleming Way', 'Staff', 'jesser@mail.com', 'password', '', '', '', '', '', 1, 'POWER SUPPLY DELL OPTIPLEX 380 MINI TOWER'),
(4, 'Nelson', 'Ford', '7458965874', '58 West Side Avenue', 'Staff', 'nelford@mail.com', 'password', '', '', '', '', '', 0, ''),
(5, 'charlie', 'puth', '5050', 'england', 'User', 'charlieputh@mail.com', 'charlie', '2', '12:00', '2022-12-05', '2022-12-05', 'Expired', 1, 'POWER SUPPLY DELL OPTIPLEX 380 MINI TOWER'),
(6, 'shaun', 'milo', '01987654', 'korea utara', 'User', 'shaunmilo@mail.com', 'shaunmilo', '', '', '', '', '', 0, '1'),
(7, 'Khalis', 'Haq', '010843576', 'Chenang', 'User', 'Khalis@mail.com', 'Haq', '', '', '', '', '', 0, 'POWER SUPPLY DELL OPTIPLEX 8500'),
(8, 'verania', 'vera', '788434', 'bali', 'User', 'veranialoissintia@gmail.com', 'vera', '', '', '', '', '', 0, ''),
(9, 'Nazifa', 'Rais', '0199667341', 'No 2, Taman Nilam', 'User', 'nazifarais02@gmail.com', 'Nu@843532', '1', '14:54', '2022-12-16', '2022-12-20', 'Expired', 1, 'Dell S2216H 22'),
(10, 'Qhaa', 'Shaa', '0111', 'Kg bukit Nau', 'User', 'nuraiqha@gmail.com', 'qhaashaa', '1', '11:20', '2022-12-05', '2022-12-05', 'Expired', 1, 'POWER SUPPLY DELL OPTIPLEX 380 MINI TOWER'),
(11, 'team', 'putri', '0108175986', 'Perak', 'User', 'teamputrifloral@gmail.com', 'Battle', '', '', '', '', '', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tms_admin`
--
ALTER TABLE `tms_admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `tms_email_message`
--
ALTER TABLE `tms_email_message`
  ADD PRIMARY KEY (`id_email_message`);

--
-- Indexes for table `tms_feedback`
--
ALTER TABLE `tms_feedback`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `tms_inventory`
--
ALTER TABLE `tms_inventory`
  ADD PRIMARY KEY (`inv_id`,`inv_name`);

--
-- Indexes for table `tms_pwd_resets`
--
ALTER TABLE `tms_pwd_resets`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `tms_user`
--
ALTER TABLE `tms_user`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `u_fname` (`u_fname`,`u_inv_bookdate`,`u_inv_returndate`),
  ADD KEY `inv_name_fk` (`inv_name`),
  ADD KEY `inv_id` (`inv_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tms_admin`
--
ALTER TABLE `tms_admin`
  MODIFY `a_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tms_email_message`
--
ALTER TABLE `tms_email_message`
  MODIFY `id_email_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tms_feedback`
--
ALTER TABLE `tms_feedback`
  MODIFY `f_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tms_inventory`
--
ALTER TABLE `tms_inventory`
  MODIFY `inv_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tms_pwd_resets`
--
ALTER TABLE `tms_pwd_resets`
  MODIFY `r_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tms_user`
--
ALTER TABLE `tms_user`
  MODIFY `u_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
