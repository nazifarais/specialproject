<?php 
include('vendor/inc/config.php');
$email = $_GET['email'];
 ?>

<!DOCTYPE html>
<html>
   <head>
      <title>All Message</title>
      <link rel="stylesheet" href="../admin/vendor/Appscript/style.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   </head>
   <body>
      <div class="wrapper" style="width: 500px;">
            <h2>History Message Notification</h2><br>
             <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0" style="text-align: left;">
            <?php 
            $nomor = 1;
         $get_message = mysqli_query($mysqli, "SELECT * FROM tms_email_message INNER JOIN tms_user ON tms_user.u_email=tms_email_message.email WHERE email='$email'");
         while ($message = mysqli_fetch_array($get_message)) { ?>
             <tr>
               <td> <?php echo $nomor++ ?></td>
               <td><button onclick="hapus_badge(<?php echo $message['id_email_message']; ?>)" class="btn btn-link" title="See Message">
                  <i class="fas fa-envelope mr-2"></i><?php echo $message['u_fname'] ?>, You Have New Message! <br>
                     <span class="text-muted text-sm"><?php echo $message['date_message'] ?></span>
                        </button></td>
            </tr>
         <?php } ?>

         <tr><td colspan="2" style="text-align: center;"><a class="nav-link" href="user-dashboard.php">Back To Dashboard</a></td></tr>
            
      </table>
      </div>
      
   </body>
</html>

 <script type="text/javascript">
    function hapus_badge(id_message){
        $.ajax({
            url:"delete_badges.php",
            data: "id_message=" + id_message+"&aksi=detele_badge",
            success: function(html) {
              window.location.href="user-message.php?id_email_message="+id_message;
            }
        });
    }
</script>