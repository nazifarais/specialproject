<?php 
include('vendor/inc/config.php');
$id_email_message = $_GET['id_email_message'];
 ?>

<!DOCTYPE html>
<html>
   <head>
      <title>See Details</title>
      <link rel="stylesheet" href="../admin/vendor/Appscript/style.css">
   </head>
   <body>
      <div class="wrapper" style="width: 700px;">
            <h2>Message Details</h2><br>
             <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0" style="text-align: left;">
            <?php 
         $get_message = mysqli_query($mysqli, "SELECT * FROM tms_email_message WHERE id_email_message='$id_email_message'");
         while ($message = mysqli_fetch_array($get_message)) { ?>
             <tr>
               <th>Your Email</th>
               <th>: </th>
               <td><input type="text" class="form-control" value="<?php echo $message['email']; ?>" readonly></td>
            </tr>
            <tr>
               <th>Subject</th>
               <th>: </th>
               <td><input type="text" class="form-control" value="<?php echo $message['subject']; ?>" readonly></td>
            </tr>
            <tr>
               <th>Your Message</th>
               <th>: </th>
               <td><textarea class="form-control" readonly><?php echo $message['body']; ?></textarea></td>
            </tr>
             <tr>
               <th>Date/Time</th>
               <th>: </th>
               <td><input type="text" class="form-control" value="<?php echo $message['date_message']; ?>" readonly></td>
            </tr>
            <tr><td colspan="3" style="text-align: center;"><a class="nav-link" href="user-dashboard.php">Back To Dashboard</a></td></tr>
            <tr><td colspan="3" style="text-align: center;"><a href="user-seeAllNotif.php?email=<?php echo $message['email']; ?>" class="dropdown-item dropdown-footer" title="See All">See All Notifications</a></td></tr>            
         <?php } ?>
      </table>
      </div>
      
   </body>
</html>