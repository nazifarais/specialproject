<?php
include('vendor/inc/config.php');
if ($_GET['aksi']=='detele_badge') {
$id_message = $_GET["id_message"];
$update_notif = mysqli_query($mysqli, "UPDATE tms_email_message SET status='1' WHERE id_email_message='$id_message'");
}
?>